import BlogGenerator from "../components/BlogGenerator";

const Index = () => {
  return <BlogGenerator />;
};

export default Index;
